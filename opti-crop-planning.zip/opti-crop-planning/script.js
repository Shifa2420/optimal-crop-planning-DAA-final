// Crop data categorized by seasons
const cropsData = {
  kharif: [
    { name: "Rice", cost: 2000, land: 2, profit: 3500 },
    { name: "Maize", cost: 1800, land: 1.5, profit: 2700 },
    { name: "Cotton", cost: 2200, land: 2, profit: 3200 },
    { name: "Soybean", cost: 1500, land: 1, profit: 2000 }
  ],
  rabi: [
    { name: "Wheat", cost: 1600, land: 1.5, profit: 2500 },
    { name: "Barley", cost: 1400, land: 1, profit: 1900 },
    { name: "Gram", cost: 1200, land: 1, profit: 1800 },
    { name: "Mustard", cost: 1800, land: 1.5, profit: 2800 }
  ],
  zaid: [
    { name: "Watermelon", cost: 1000, land: 1, profit: 1500 },
    { name: "Cucumber", cost: 1200, land: 1, profit: 1800 },
    { name: "Bitter Gourd", cost: 1300, land: 1, profit: 2000 },
    { name: "Pumpkin", cost: 1100, land: 1, profit: 1700 }
  ]
};

function calculatePlan() {
  const season = document.getElementById("season").value;
  const totalLand = parseFloat(document.getElementById("land").value);
  const totalBudget = parseFloat(document.getElementById("budget").value);
  const resultDiv = document.getElementById("result");

  if (!season || isNaN(totalLand) || isNaN(totalBudget)) {
    resultDiv.innerHTML = "<p style='color:red;'>⚠️ Please fill all fields correctly.</p>";
    return;
  }

  const crops = cropsData[season];
  const n = crops.length;

  // DP table: max profit for given budget
  let dp = Array.from({ length: n + 1 }, () =>
    Array(totalBudget + 1).fill(0)
  );

  for (let i = 1; i <= n; i++) {
    for (let b = 0; b <= totalBudget; b++) {
      if (crops[i - 1].cost <= b) {
        dp[i][b] = Math.max(
          crops[i - 1].profit + dp[i - 1][b - crops[i - 1].cost],
          dp[i - 1][b]
        );
      } else {
        dp[i][b] = dp[i - 1][b];
      }
    }
  }

  // Backtrack to find selected crops
  let res = dp[n][totalBudget];
  let w = totalBudget;
  let selected = [];

  for (let i = n; i > 0 && res > 0; i--) {
    if (res !== dp[i - 1][w]) {
      selected.push(crops[i - 1]);
      res -= crops[i - 1].profit;
      w -= crops[i - 1].cost;
    }
  }

  let usedLand = selected.reduce((sum, c) => sum + c.land, 0);

  if (usedLand > totalLand) {
    resultDiv.innerHTML = `<p style='color:red;'>🚫 Land not sufficient for the selected crops. Try more area or lower budget.</p>`;
    return;
  }

  // Display results
  resultDiv.innerHTML = `
    <h3>🌾 Recommended Crop Plan (${season.toUpperCase()} Season)</h3>
    <ul style="text-align:left; margin-left: 20px;">
      ${selected.map(c => `<li><b>${c.name}</b> — Profit: ₹${c.profit}, Land: ${c.land} acres</li>`).join("")}
    </ul>
    <p><strong>Total Expected Profit:</strong> ₹${dp[n][totalBudget]}</p>
    <p><strong>Total Land Used:</strong> ${usedLand.toFixed(2)} acres</p>
  `;
}
